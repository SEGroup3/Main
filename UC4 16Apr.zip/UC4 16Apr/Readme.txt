      Analysis window


>This window is the last part of the program to run and meets the requirements set out in Use case 4.

>It provides an interface to view the csv output of the other parts of the process.

>The user can sort them and load custom files to view. 

>There are elements that some people may want to reuse, the error messages (messagebox)
 in particular are extremely useful, as is the status bar for aesthetics.

>The only thing I just cant solve in the whole program is if the user deliberately uploads
 a file that is not a text based file (the program can be manipulated to achieve this, although 
 it this not an easly mistake to make) . This causes the chart to go blank. Simply selecting 
 'default' resets this. The 'default' button can be used as a general reset throughout.

>read the help pop ups for more info on using this



CD